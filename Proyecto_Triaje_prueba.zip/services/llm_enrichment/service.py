"""
services/llm_enrichment/service.py
Llama a Ollama, parsea el JSON clínico y persiste en Postgres.
"""
import os
import json
import logging
import httpx
from datetime import datetime

from common import pg_execute, update_estado, now
from llm_enrichment.prompt import build_messages

logger = logging.getLogger(__name__)

OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://host.docker.internal:11434")
OLLAMA_MODEL    = os.environ.get("OLLAMA_MODEL", "llama3.1:70b-instruct-q4_K_M")
TIMEOUT         = 120  # segundos


def call_ollama(transcripcion: str) -> dict:
    """Llama a Ollama y devuelve el JSON parseado."""
    messages = build_messages(transcripcion)
    payload = {
        "model": OLLAMA_MODEL,
        "messages": messages,
        "stream": False,
        "format": "json",
    }
    resp = httpx.post(
        f"{OLLAMA_BASE_URL}/api/chat",
        json=payload,
        timeout=TIMEOUT,
    )
    resp.raise_for_status()
    raw = resp.json()["message"]["content"]

    # Limpieza defensiva de markdown fences
    clean = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
    return json.loads(clean)


def enrich(guid: str, texto: str) -> dict:
    """
    Enriquece una entrevista:
    1. Llama al LLM.
    2. Persiste entidades en tabla Entidad.
    3. Persiste features y nivel_triaje en ResultadoML.
    4. Actualiza estado → ENRICHED.
    """
    t_inicio = now()
    update_estado(guid, "ENRICHING", Inicio_Extraccion_Entidades=t_inicio)

    resultado = call_ollama(texto)

    # ── Entidades ──────────────────────────────────────────────────────────────
    entidades_raw  = resultado.get("entidades", [])
    entidades_norm = resultado.get("entidades_normalizadas", [])

    for raw, norm in zip(entidades_raw, entidades_norm):
        pg_execute(
            """INSERT INTO Entidad (GUID_Entrevista, entidad_raw, entidad_normalizada, tipo)
               VALUES (%s, %s, %s, %s)""",
            (guid, raw, norm, "sintoma"),
        )

    # ── ResultadoML ────────────────────────────────────────────────────────────
    pg_execute(
        """INSERT INTO ResultadoML
           (GUID_Entrevista, edad, sexo, dolor_intensidad, disnea, fiebre,
            perdida_consciencia, irradiacion, antecedentes_cardiacos, fumador,
            motivo_consulta, justificacion, score_urgencia, nivel_triaje, timestamp_pred)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
           ON CONFLICT DO NOTHING""",
        (
            guid,
            resultado.get("edad"),
            resultado.get("sexo"),
            resultado.get("dolor_intensidad"),
            resultado.get("disnea", False),
            resultado.get("fiebre", False),
            resultado.get("perdida_consciencia", False),
            resultado.get("irradiacion", False),
            resultado.get("antecedentes_cardiacos", False),
            resultado.get("fumador", False),
            resultado.get("motivo_consulta"),
            resultado.get("justificacion"),
            resultado.get("score_urgencia"),
            resultado.get("nivel_triaje"),
            now(),
        ),
    )

    t_fin = now()
    update_estado(
        guid, "ENRICHED",
        Fin_Extraccion_Entidades=t_fin,
        Inicio_Normalizacion=t_inicio,
        Fin_Normalizacion=t_fin,
        Inicio_Etiquetado=t_inicio,
        Fin_Etiquetado=t_fin,
        Inicio_Score=t_inicio,
        Fin_Score=t_fin,
    )

    logger.info(f"[{guid}] ENRICHED — nivel_triaje={resultado.get('nivel_triaje')}")
    return resultado
