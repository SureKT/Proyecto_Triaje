"""
dags/dag_llm_enrichment.py
Para cada entrevista en estado INGESTED, llama al servicio de enriquecimiento LLM.
"""
import os
import logging
from datetime import datetime, timedelta

import httpx
from airflow import DAG
from airflow.operators.python import PythonOperator

logger = logging.getLogger(__name__)

API_BASE = os.environ.get("API_BASE_URL", "http://api:8000")
TIMEOUT  = 180

DEFAULT_ARGS = {
    "owner": "triaje",
    "retries": 3,
    "retry_delay": timedelta(seconds=60),
    "retry_exponential_backoff": True,
}


def _enrich_all():
    import sys
    sys.path.insert(0, "/opt/airflow/dags")
    from common import pg_execute, minio_download_text, update_estado

    bucket = os.environ["MINIO_BUCKET_TEXTOS"]

    rows = pg_execute(
        "SELECT GUID_Entrevista, URL_Texto_Original FROM Entrevista WHERE Estado = 'INGESTED'",
        fetch=True,
    )
    if not rows:
        logger.info("No hay entrevistas en estado INGESTED.")
        return

    ok = err = 0
    for row in rows:
        guid = row["guid_entrevista"]
        url  = row["url_texto_original"]
        try:
            # Extraer object_name de la URL
            object_name = "/".join(url.split("/")[4:])
            texto = minio_download_text(bucket, object_name)

            resp = httpx.post(
                f"{API_BASE}/enriquecer/",
                json={"guid": guid, "texto": texto},
                timeout=TIMEOUT,
            )
            resp.raise_for_status()
            ok += 1
            logger.info(f"ENRICHED {guid}")

        except Exception as e:
            logger.error(f"ERROR enriqueciendo {guid}: {e}")
            update_estado(guid, "ERROR_ENRICHMENT")
            err += 1

    logger.info(f"Enriquecimiento completo — ok={ok}  errores={err}")
    if err:
        raise RuntimeError(f"{err} entrevistas fallaron en el enriquecimiento.")


with DAG(
    dag_id="dag_llm_enrichment",
    description="Enriquecimiento LLM de todas las entrevistas INGESTED",
    start_date=datetime(2024, 1, 1),
    schedule_interval=None,
    catchup=False,
    default_args=DEFAULT_ARGS,
    tags=["triaje", "fase1"],
) as dag:

    enrich = PythonOperator(
        task_id="enrich_all",
        python_callable=_enrich_all,
    )
